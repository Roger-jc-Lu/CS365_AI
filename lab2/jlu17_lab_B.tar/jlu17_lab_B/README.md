﻿# This is the readme for lab B

The `playGame.py` file uses argparse.
To see the result of game play, run `python3 .\playGame.py -h` first under the uncompressed directory `.\jlu17_lab_B` to see the help information for arguments input.

A sample input comand could be `python3 .\playGame.py -y 8 -x 8 -p 2 -a e -b c`

---

Contributor: Roger Lu, Ali Gokcelioglu